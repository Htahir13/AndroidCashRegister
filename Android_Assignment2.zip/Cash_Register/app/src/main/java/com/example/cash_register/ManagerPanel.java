package com.example.cash_register;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.MenuItem;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ManagerPanel extends AppCompatActivity {

    Button historyButton;
    Button restockButton;

    CashRegister register;
    History history;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
         register = (CashRegister) getIntent().getSerializableExtra("register");
         history = (History) getIntent().getSerializableExtra("history");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manager_panel);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        historyButton = findViewById(R.id.history);
        restockButton = findViewById(R.id.restock);

        if (savedInstanceState != null) {
            register = (CashRegister) savedInstanceState.getSerializable("register");
            history = (History) savedInstanceState.getSerializable("history");
        }


        historyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ManagerPanel.this, HistoryList.class);
                intent.putExtra("history", history);
                startActivity(intent);

            }
        });

        restockButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ManagerPanel.this, Restock.class);
                intent.putExtra("register", register);
                startActivity(intent);

            }
        });





    }

    // Code responsible for implementing back button functionality
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putSerializable("register", register);
        outState.putSerializable("history", history);
    }



}