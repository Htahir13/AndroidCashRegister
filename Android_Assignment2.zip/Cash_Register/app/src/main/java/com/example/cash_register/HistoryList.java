package com.example.cash_register;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


public class HistoryList extends AppCompatActivity {

    ListView listView;
    private Product selectedProduct;

    History history;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        history = (History) getIntent().getSerializableExtra("history");
        ArrayList<Date> dates = history.getCorrespondingDates();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_list);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        listView = findViewById(R.id.historyListView);


        if (savedInstanceState != null) {
            history = (History) savedInstanceState.getSerializable("history");
        }


        RegisterAdapter adapter = new RegisterAdapter(getApplicationContext(), R.layout.activity_list_view, history.getHistoryList());
        listView.setAdapter(adapter);



        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedProduct = (Product) parent.getItemAtPosition(position);
                DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
                String strDate = dateFormat.format(dates.get(position));
                Intent intent = new Intent(HistoryList.this, HistoryDetails.class);
                intent.putExtra("product", selectedProduct);
                intent.putExtra("date", strDate);
                startActivity(intent);

            }
        });

    }


    // Code responsible for implementing back button functionality
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putSerializable("history", history);
    }



}