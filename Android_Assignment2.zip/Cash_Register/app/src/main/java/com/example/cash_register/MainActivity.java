package com.example.cash_register;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    TextView productName;
    TextView totalPrice;
    TextView productQuantity;

    CashRegister register;

    History history;

    NumberPicker quantity_picker;

    Button manager;
    Button buy;

    private Product selectedProduct;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        productName = findViewById(R.id.productName);
        productQuantity = findViewById(R.id.quantity);
        totalPrice = findViewById(R.id.totalPrice);
        quantity_picker = findViewById(R.id.quantity_picker);
        manager = findViewById(R.id.registerManager);
        buy = findViewById(R.id.registerBuy);

        if (savedInstanceState != null) {
            register = (CashRegister) savedInstanceState.getSerializable("register");
            history = (History) savedInstanceState.getSerializable("history");
            productName.setText(savedInstanceState.getString("product"));
            totalPrice.setText(savedInstanceState.getString("price"));
            quantity_picker.setValue(savedInstanceState.getInt("quantityPicker"));



        }
        else{
            if(getIntent().getSerializableExtra("register") == null) {
                register = new CashRegister();
                history = new History();
            }
            else{
                history = new History();
                register = (CashRegister) getIntent().getSerializableExtra("register");
            }

        }


        RegisterAdapter adapter = new RegisterAdapter(getApplicationContext(), R.layout.activity_list_view,register.getRegister() );
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedProduct = (Product) parent.getItemAtPosition(position);
                productName.setText(selectedProduct.getP_Name());
            }
        });

        quantity_picker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
                if(selectedProduct != null) {
                    if (picker.getValue() > selectedProduct.getP_quantity()) {
                        Toast.makeText(MainActivity.this, "Not enough quantity in the stock!", Toast.LENGTH_SHORT).show();
                    } else {
                        double total = picker.getValue() * selectedProduct.getP_price();
                        total = Math.round(total);
                        totalPrice.setText(String.valueOf(total));
                        productQuantity.setText(String.valueOf(picker.getValue()));
                    }
                }
                else{
                    Toast.makeText(MainActivity.this, "Select a product first!", Toast.LENGTH_SHORT).show();

                }
            }
        });

        buy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(selectedProduct != null){
                    if (quantity_picker.getValue() > selectedProduct.getP_quantity()) {
                        Toast.makeText(MainActivity.this, "Not enough quantity in the stock!", Toast.LENGTH_SHORT).show();
                    } else {
                        selectedProduct.purchase(quantity_picker.getValue());
                        history.addProduct(new Product(selectedProduct.getP_Name(), selectedProduct.getP_price(), quantity_picker.getValue()));
                        Snackbar.make(view, "Thank you for buying " + String.valueOf(quantity_picker.getValue()) + " " + selectedProduct.getP_Name() + "at the price of " + totalPrice.getText(), Snackbar.LENGTH_LONG).show();


                        totalPrice.setText("0.00");
                        quantity_picker.setValue(0);
                        adapter.notifyDataSetChanged();

                    }

                }
                else{
                    Toast.makeText(MainActivity.this, "Select a product first!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        manager.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ManagerPanel.class);
                intent.putExtra("register", register);
                intent.putExtra("history", history);
                startActivity(intent);
            }
        });

        quantity_picker.setMaxValue(100);
        quantity_picker.setMinValue(0);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putSerializable("register", register);
        outState.putSerializable("history", history);
        outState.putInt("quantityPicker", quantity_picker.getValue());
        outState.putString("product", productName.getText().toString());
        outState.putString("price", totalPrice.getText().toString());

    }

}