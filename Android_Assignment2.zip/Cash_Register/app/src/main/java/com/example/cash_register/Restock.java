package com.example.cash_register;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class Restock extends AppCompatActivity {
    ListView listView;
    EditText textField;

    Button okButton, cancelButton;
    private Product selectedProduct;
    private CashRegister register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        register = (CashRegister) getIntent().getSerializableExtra("register");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restock);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        listView = findViewById(R.id.restockList);
        textField = findViewById(R.id.newQuantity);
        okButton = findViewById(R.id.okButton);
        cancelButton = findViewById(R.id.cancelButton);

        if (savedInstanceState != null) {
            register = (CashRegister) savedInstanceState.getSerializable("register");
        }

        RegisterAdapter adapter = new RegisterAdapter(getApplicationContext(), R.layout.activity_list_view,register.getRegister() );
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedProduct = (Product) parent.getItemAtPosition(position);
                Toast.makeText(Restock.this, "You have selected the " + selectedProduct.getP_Name() + " to restock!", Toast.LENGTH_SHORT).show();


            }
        });

        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(selectedProduct != null){

                    try{
                        String enteredQuantity = textField.getText().toString();
                        int quantityToAdd = Integer.parseInt(enteredQuantity);

                        selectedProduct.restock(quantityToAdd);

                        Toast.makeText(Restock.this, "Restock has been successfully completed", Toast.LENGTH_SHORT).show();
                        adapter.notifyDataSetChanged();


                    }
                    catch (Exception e){
                        Toast.makeText(Restock.this, "You must enter a valid number", Toast.LENGTH_SHORT).show();

                    }

                }
                else{
                    Toast.makeText(Restock.this, "Please select an option first!", Toast.LENGTH_SHORT).show();

                }
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Restock.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("register", register);
                startActivity(intent);
                finish();


            }
        });



    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_OK);
        finish();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putSerializable("register", register);
    }

}