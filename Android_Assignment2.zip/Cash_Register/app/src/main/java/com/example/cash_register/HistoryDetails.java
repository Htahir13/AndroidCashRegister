package com.example.cash_register;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

public class HistoryDetails extends AppCompatActivity {

    TextView name, purchaseDate, price;
    Product product;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        product = (Product) getIntent().getSerializableExtra("product");
        String date = getIntent().getStringExtra("date");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_details);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        name = findViewById(R.id.name);
        purchaseDate = findViewById(R.id.purchaseDate);
        price = findViewById(R.id.price);

        if (savedInstanceState != null) {
            product = (Product) savedInstanceState.getSerializable("product");
        }


        name.setText("Product: " + product.getP_Name());
        purchaseDate.setText("Purchase Date: " + date);
        price.setText(String.valueOf("Price: " + product.getP_price()));


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putSerializable("product", product);
    }

}