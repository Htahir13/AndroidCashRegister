package com.example.cash_register;

import java.io.Serializable;
import java.util.Date;

public class Product implements Serializable {
   private String p_Name;
   private double p_price;
   private int p_quantity;



    Product(String p_Name, double p_price, int p_quantity){
        this.p_Name = p_Name;
        this.p_price = p_price;
        this.p_quantity = p_quantity;


    }

    public double getP_price() {
        return p_price;
    }

    public int getP_quantity() {
        return p_quantity;
    }

    public String getP_Name() {
        return p_Name;
    }

    public void purchase(int p_quantity){
        this.p_quantity -= p_quantity;
    }

    public void restock(int p_quantity){
        this.p_quantity += p_quantity;
    }

}
