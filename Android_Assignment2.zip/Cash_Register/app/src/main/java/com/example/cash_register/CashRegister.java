package com.example.cash_register;

import java.io.Serializable;
import java.util.ArrayList;

public class CashRegister implements Serializable {
    private static ArrayList<Product> register = new ArrayList<>();

    CashRegister(){
        register.add(new Product("Pante", 20.44, 10));
        register.add(new Product("Shoes", 10.44, 80));
        register.add(new Product("Hats", 5.99, 30));
    }

    public static ArrayList<Product> getRegister() {
        return register;
    }

    public Product getProduct(String p_name){
        Product retval = null;
        for(int i = 0; i < register.size(); i++){
            if(register.get(i).getP_Name().equals(p_name)){
                retval = register.get(i);
            }
        }

        return retval;
    }
}
