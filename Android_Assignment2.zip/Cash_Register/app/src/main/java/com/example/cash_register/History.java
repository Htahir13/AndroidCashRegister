package com.example.cash_register;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

public class History implements Serializable {
    private static ArrayList<Product> historyList = new ArrayList<>();
    private static ArrayList<Date> correspondingDates = new ArrayList<>();
    private Date date;

    public void addProduct(Product product){
        historyList.add(product);
        correspondingDates.add(new Date());
    }

    public static ArrayList<Product> getHistoryList() {
        return historyList;
    }

    public static ArrayList<Date> getCorrespondingDates() {
        return correspondingDates;
    }
}
