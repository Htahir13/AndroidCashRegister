package com.example.cash_register;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class RegisterAdapter extends ArrayAdapter<Product> {

    private ArrayList<Product> productList;

    public RegisterAdapter(@NonNull Context context, int resource, ArrayList<Product> productList) {
        super(context, resource, productList);
        this.productList = productList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        int titleIndex = position;
        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.activity_list_view, parent, false);

        }

        TextView productName = convertView.findViewById(R.id.productName);
        TextView productQuantity = convertView.findViewById(R.id.productQuantity);
        TextView productPrice = convertView.findViewById(R.id.productPrice);

        productName.setText(productList.get(position).getP_Name());
        productPrice.setText(String.valueOf(productList.get(position).getP_price()));
        productQuantity.setText(String.valueOf(productList.get(position).getP_quantity()));

        return convertView;
    }
}
